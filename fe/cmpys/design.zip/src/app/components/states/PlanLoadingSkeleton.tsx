import React from 'react';
import { motion } from 'motion/react';

export function PlanLoadingSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3, 4].map((index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1, duration: 0.4 }}
          className="bg-[#1C1C1E] rounded-[16px] p-4 border border-[#2A2A2E]"
        >
          <div className="flex items-start gap-3">
            {/* Checkbox skeleton */}
            <motion.div
              animate={{
                opacity: [0.4, 0.8, 0.4],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="w-5 h-5 rounded border-2 border-[#2A2A2E] flex-shrink-0 mt-0.5"
            />
            
            <div className="flex-1">
              {/* Title skeleton */}
              <motion.div
                animate={{
                  opacity: [0.4, 0.8, 0.4],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: 'easeInOut',
                  delay: 0.1,
                }}
                className="h-4 bg-[#2A2A2E] rounded-full w-4/5 mb-2"
              />
              
              {/* Meta info skeleton */}
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{
                    opacity: [0.4, 0.8, 0.4],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: 'easeInOut',
                    delay: 0.2,
                  }}
                  className="h-3 bg-[#2A2A2E] rounded-full w-16"
                />
                <div className="w-1 h-1 rounded-full bg-[#2A2A2E]" />
                <motion.div
                  animate={{
                    opacity: [0.4, 0.8, 0.4],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: 'easeInOut',
                    delay: 0.3,
                  }}
                  className="h-3 bg-[#2A2A2E] rounded-full w-20"
                />
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
