import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import { PrimaryButton } from '../PrimaryButton';

interface ImportFailedStateProps {
  onRetry?: () => void;
  onGoBack?: () => void;
  errorMessage?: string;
}

export function ImportFailedState({ 
  onRetry, 
  onGoBack,
  errorMessage = 'Unable to import idol timeline. Please check your connection and try again.'
}: ImportFailedStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center py-12"
    >
      {/* Icon */}
      <motion.div
        animate={{
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="w-24 h-24 rounded-full bg-gradient-to-br from-[#FF6B6B] to-[#F87171] flex items-center justify-center mb-6 shadow-2xl shadow-[#FF6B6B]/20"
      >
        <AlertCircle className="w-12 h-12 text-white" />
      </motion.div>

      {/* Title */}
      <h2 className="text-white text-xl mb-3 text-center">
        Import failed
      </h2>

      {/* Description */}
      <p className="text-[#A1A1AA] text-center mb-8 max-w-xs px-4">
        {errorMessage}
      </p>

      {/* Action Buttons */}
      <div className="space-y-3 w-full max-w-xs px-4">
        {onRetry && (
          <PrimaryButton onClick={onRetry}>
            <div className="flex items-center gap-2">
              <RefreshCw className="w-5 h-5" />
              <span>Try again</span>
            </div>
          </PrimaryButton>
        )}
        
        {onGoBack && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onGoBack}
            className="w-full px-6 py-4 rounded-[20px] bg-[#1C1C1E] text-white border border-[#2A2A2E] hover:border-[#7B61FF]/30 transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Choose another idol</span>
          </motion.button>
        )}
      </div>

      {/* Error Details Card */}
      <div className="mt-8 bg-[#1C1C1E] rounded-[20px] p-4 border border-[#2A2A2E] w-full max-w-sm">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-[#FF6B6B] flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="text-white text-sm mb-2">Common issues</h3>
            <div className="space-y-2">
              {[
                'Check your internet connection',
                'Verify the source is available',
                'Try a different idol',
              ].map((tip, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1, duration: 0.4 }}
                  className="flex items-center gap-2"
                >
                  <div className="w-1 h-1 rounded-full bg-[#A1A1AA]" />
                  <span className="text-[#A1A1AA] text-sm">{tip}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
