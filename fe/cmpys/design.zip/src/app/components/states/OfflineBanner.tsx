import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { WifiOff, X } from 'lucide-react';

interface OfflineBannerProps {
  isVisible: boolean;
  onDismiss?: () => void;
}

export function OfflineBanner({ isVisible, onDismiss }: OfflineBannerProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -100, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="fixed top-0 left-0 right-0 z-50 px-6 pt-14 pb-3"
          style={{ maxWidth: '390px', margin: '0 auto' }}
        >
          <div className="bg-[#FF6B6B] rounded-[16px] p-4 shadow-2xl shadow-[#FF6B6B]/40 border border-[#FF8787]">
            <div className="flex items-center gap-3">
              {/* Icon */}
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
                className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0"
              >
                <WifiOff className="w-5 h-5 text-white" />
              </motion.div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-medium mb-0.5">
                  You're offline
                </h3>
                <p className="text-white/90 text-sm">
                  Some features may be limited
                </p>
              </div>

              {/* Dismiss Button */}
              {onDismiss && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onDismiss}
                  className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0 hover:bg-white/30 transition-colors"
                >
                  <X className="w-5 h-5 text-white" />
                </motion.button>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
