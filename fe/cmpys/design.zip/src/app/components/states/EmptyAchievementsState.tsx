import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Plus } from 'lucide-react';
import { PrimaryButton } from '../PrimaryButton';

interface EmptyAchievementsStateProps {
  onAddAchievement?: () => void;
}

export function EmptyAchievementsState({ onAddAchievement }: EmptyAchievementsStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center py-12"
    >
      {/* Icon */}
      <motion.div
        animate={{
          scale: [1, 1.05, 1],
          y: [0, -8, 0],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="w-24 h-24 rounded-full bg-gradient-to-br from-[#7B61FF] to-[#A78BFA] flex items-center justify-center mb-6 shadow-2xl shadow-[#7B61FF]/20"
      >
        <Trophy className="w-12 h-12 text-white" />
      </motion.div>

      {/* Title */}
      <h2 className="text-white text-xl mb-3 text-center">
        No achievements yet
      </h2>

      {/* Description */}
      <p className="text-[#A1A1AA] text-center mb-8 max-w-xs px-4">
        Start tracking your journey by adding your first achievement
      </p>

      {/* CTA Button */}
      {onAddAchievement && (
        <PrimaryButton onClick={onAddAchievement}>
          <div className="flex items-center gap-2">
            <Plus className="w-5 h-5" />
            <span>Add your first achievement</span>
          </div>
        </PrimaryButton>
      )}

      {/* Info Card */}
      <div className="mt-8 bg-[#1C1C1E] rounded-[20px] p-4 border border-[#2A2A2E] w-full max-w-sm">
        <div className="space-y-3">
          {[
            'Track milestones',
            'Compare with idols',
            'Build your timeline',
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1, duration: 0.4 }}
              className="flex items-center gap-3"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-[#7B61FF]" />
              <span className="text-[#A1A1AA] text-sm">{feature}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
