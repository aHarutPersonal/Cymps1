import React from 'react';
import { motion } from 'motion/react';

export function TimelineLoadingSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1, duration: 0.4 }}
          className="bg-[#1C1C1E] rounded-[20px] p-4 border border-[#2A2A2E]"
        >
          {/* Header skeleton */}
          <div className="flex items-start gap-3 mb-3">
            {/* Avatar skeleton */}
            <motion.div
              animate={{
                opacity: [0.4, 0.8, 0.4],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="w-12 h-12 rounded-full bg-[#2A2A2E]"
            />
            <div className="flex-1">
              {/* Title skeleton */}
              <motion.div
                animate={{
                  opacity: [0.4, 0.8, 0.4],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: 'easeInOut',
                  delay: 0.1,
                }}
                className="h-4 bg-[#2A2A2E] rounded-full w-3/4 mb-2"
              />
              {/* Subtitle skeleton */}
              <motion.div
                animate={{
                  opacity: [0.4, 0.8, 0.4],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: 'easeInOut',
                  delay: 0.2,
                }}
                className="h-3 bg-[#2A2A2E] rounded-full w-1/2"
              />
            </div>
          </div>

          {/* Description skeleton */}
          <div className="space-y-2">
            <motion.div
              animate={{
                opacity: [0.4, 0.8, 0.4],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: 0.3,
              }}
              className="h-3 bg-[#2A2A2E] rounded-full w-full"
            />
            <motion.div
              animate={{
                opacity: [0.4, 0.8, 0.4],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: 0.4,
              }}
              className="h-3 bg-[#2A2A2E] rounded-full w-5/6"
            />
          </div>
        </motion.div>
      ))}
    </div>
  );
}
