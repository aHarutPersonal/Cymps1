import React from 'react';
import { motion } from 'motion/react';
import { Target, Sparkles } from 'lucide-react';
import { PrimaryButton } from '../PrimaryButton';

interface EmptyPlanStateProps {
  onGeneratePlan?: () => void;
}

export function EmptyPlanState({ onGeneratePlan }: EmptyPlanStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center py-12"
    >
      {/* Icon */}
      <motion.div
        animate={{
          scale: [1, 1.05, 1],
          rotate: [0, 5, 0, -5, 0],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="relative mb-6"
      >
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#7B61FF] to-[#A78BFA] flex items-center justify-center shadow-2xl shadow-[#7B61FF]/20">
          <Target className="w-12 h-12 text-white" />
        </div>
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 1, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute -top-1 -right-1 w-8 h-8 rounded-full bg-[#FBBF24] flex items-center justify-center"
        >
          <Sparkles className="w-4 h-4 text-white" />
        </motion.div>
      </motion.div>

      {/* Title */}
      <h2 className="text-white text-xl mb-3 text-center">
        Generate your first plan
      </h2>

      {/* Description */}
      <p className="text-[#A1A1AA] text-center mb-8 max-w-xs px-4">
        Create a personalized action plan based on your idol's journey and your current progress
      </p>

      {/* CTA Button */}
      {onGeneratePlan && (
        <PrimaryButton onClick={onGeneratePlan}>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            <span>Generate plan</span>
          </div>
        </PrimaryButton>
      )}

      {/* Features List */}
      <div className="mt-8 bg-[#1C1C1E] rounded-[20px] p-4 border border-[#2A2A2E] w-full max-w-sm">
        <div className="space-y-3">
          {[
            'AI-powered action steps',
            'Based on idol insights',
            'Track your progress',
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1, duration: 0.4 }}
              className="flex items-center gap-3"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-[#7B61FF]" />
              <span className="text-[#A1A1AA] text-sm">{feature}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
