import React, { useState } from 'react';
import { SplashScreen } from './components/screens/SplashScreen';
import { AuthLandingScreen } from './components/screens/AuthLandingScreen';
import { ProfileSetupScreen } from './components/screens/ProfileSetupScreen';
import { OnboardingScreen } from './components/screens/OnboardingScreen';
import { AgeInputScreen } from './components/screens/AgeInputScreen';
import { IdolSuggestionsScreen } from './components/screens/IdolSuggestionsScreen';
import { IdolDiscoveryResultsScreen } from './components/screens/IdolDiscoveryResultsScreen';
import { ConfirmIdolScreen } from './components/screens/ConfirmIdolScreen';
import { TimelineEnrichmentScreen } from './components/screens/TimelineEnrichmentScreen';
import { AddAchievementScreen } from './components/screens/AddAchievementScreen';
import { YourAchievementsScreen } from './components/screens/YourAchievementsScreen';
import { AchievementDetailScreen } from './components/screens/AchievementDetailScreen';
import { EditAchievementScreen } from './components/screens/EditAchievementScreen';
import { EvidenceSheetDemoScreen } from './components/screens/EvidenceSheetDemoScreen';
import { ComparisonBreakdownScreen } from './components/screens/ComparisonBreakdownScreen';
import { StatesLibraryScreen } from './components/screens/StatesLibraryScreen';
import { HomeDashboard } from './components/screens/HomeDashboard';
import { IdolTimelineScreen } from './components/screens/IdolTimelineScreen';
import { ComparisonDetailsScreen } from './components/screens/ComparisonDetailsScreen';
import { PlanTrackerScreen } from './components/screens/PlanTrackerScreen';
import { PlanItemDetailScreen } from './components/screens/PlanItemDetailScreen';
import { ChatScreen } from './components/screens/ChatScreen';
import { NotesScreen } from './components/screens/NotesScreen';
import { NewNoteScreen } from './components/screens/NewNoteScreen';
import { NoteDetailDemoScreen } from './components/screens/NoteDetailDemoScreen';
import { IdolSwitcherDemoScreen } from './components/screens/IdolSwitcherDemoScreen';
import { NavigationMapScreen } from './components/screens/NavigationMapScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { EditProfileScreen } from './components/screens/EditProfileScreen';
import { NotificationsScreen } from './components/screens/NotificationsScreen';
import { IdolSearchScreen } from './components/screens/IdolSearchScreen';
import { Home, Target, MessageCircle, BookOpen, ChevronRight, FileText } from 'lucide-react';

type Screen = 
  | 'splash'
  | 'auth'
  | 'profileSetup'
  | 'onboarding'
  | 'ageInput'
  | 'idols'
  | 'discovery'
  | 'confirm'
  | 'enrichment'
  | 'addAchievement'
  | 'add-achievement'
  | 'yourAchievements'
  | 'your-achievements'
  | 'achievementDetail'
  | 'editAchievement'
  | 'evidenceDemo'
  | 'comparisonBreakdown'
  | 'comparison-breakdown'
  | 'statesLibrary'
  | 'home'
  | 'timeline'
  | 'comparison'
  | 'comparison-details'
  | 'plan'
  | 'plan-tracker'
  | 'planItemDetail'
  | 'chat'
  | 'notes'
  | 'newNote'
  | 'noteDetailDemo'
  | 'idolSwitcherDemo'
  | 'idol-suggestions'
  | 'navigationMap'
  | 'settings'
  | 'profile'
  | 'editProfile'
  | 'notifications'
  | 'idolSearch';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');

  // iPhone 14/15 dimensions
  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen onStart={() => setCurrentScreen('auth')} />;
      case 'auth':
        return (
          <AuthLandingScreen
            onContinueWithApple={() => setCurrentScreen('profileSetup')}
            onContinueWithGoogle={() => setCurrentScreen('profileSetup')}
            onContinueAsGuest={() => setCurrentScreen('profileSetup')}
          />
        );
      case 'profileSetup':
        return (
          <ProfileSetupScreen
            onContinue={() => setCurrentScreen('onboarding')}
          />
        );
      case 'onboarding':
        return (
          <OnboardingScreen
            onContinue={() => setCurrentScreen('ageInput')}
            onBack={() => setCurrentScreen('profileSetup')}
          />
        );
      case 'ageInput':
        return (
          <AgeInputScreen
            onContinue={() => setCurrentScreen('idols')}
            onBack={() => setCurrentScreen('onboarding')}
          />
        );
      case 'idols':
        return (
          <IdolSuggestionsScreen
            onContinue={() => setCurrentScreen('discovery')}
            onBack={() => setCurrentScreen('ageInput')}
          />
        );
      case 'discovery':
        return (
          <IdolDiscoveryResultsScreen
            onImport={() => setCurrentScreen('confirm')}
            onBack={() => setCurrentScreen('idols')}
          />
        );
      case 'confirm':
        return (
          <ConfirmIdolScreen
            onImport={() => setCurrentScreen('enrichment')}
            onChooseAnother={() => setCurrentScreen('discovery')}
            onBack={() => setCurrentScreen('discovery')}
          />
        );
      case 'home':
        return <HomeDashboard onNavigate={setCurrentScreen} />;
      case 'timeline':
        return <IdolTimelineScreen onBack={() => setCurrentScreen('home')} />;
      case 'comparison':
      case 'comparison-details':
        return <ComparisonDetailsScreen onBack={() => setCurrentScreen('home')} />;
      case 'plan':
      case 'plan-tracker':
        return <PlanTrackerScreen onBack={() => setCurrentScreen('home')} />;
      case 'planItemDetail':
        return <PlanItemDetailScreen onBack={() => setCurrentScreen('plan')} />;
      case 'chat':
        return <ChatScreen onBack={() => setCurrentScreen('home')} />;
      case 'notes':
        return (
          <NotesScreen
            onBack={() => setCurrentScreen('home')}
            onCreateNote={() => setCurrentScreen('newNote')}
          />
        );
      case 'newNote':
        return (
          <NewNoteScreen
            onBack={() => setCurrentScreen('notes')}
            onSave={(note) => {
              console.log('Note saved:', note);
              setCurrentScreen('notes');
            }}
          />
        );
      case 'noteDetailDemo':
        return (
          <NoteDetailDemoScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'idolSwitcherDemo':
      case 'idol-suggestions':
        return (
          <IdolSwitcherDemoScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'navigationMap':
        return (
          <NavigationMapScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'settings':
        return (
          <SettingsScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'enrichment':
        return (
          <TimelineEnrichmentScreen
            onBack={() => setCurrentScreen('confirm')}
            onViewPartial={() => setCurrentScreen('timeline')}
            onRetry={() => setCurrentScreen('enrichment')}
            onChangeIdol={() => setCurrentScreen('idols')}
          />
        );
      case 'addAchievement':
      case 'add-achievement':
        return (
          <AddAchievementScreen
            onBack={() => setCurrentScreen('yourAchievements')}
            onSave={(achievement) => {
              console.log('Achievement saved:', achievement);
              setCurrentScreen('yourAchievements');
            }}
          />
        );
      case 'yourAchievements':
      case 'your-achievements':
        return (
          <YourAchievementsScreen
            onBack={() => setCurrentScreen('home')}
            onAddAchievement={() => setCurrentScreen('addAchievement')}
          />
        );
      case 'achievementDetail':
        return (
          <AchievementDetailScreen
            onBack={() => setCurrentScreen('yourAchievements')}
            onEdit={() => setCurrentScreen('editAchievement')}
          />
        );
      case 'editAchievement':
        return (
          <EditAchievementScreen
            onBack={() => setCurrentScreen('achievementDetail')}
            onSave={(achievement) => {
              console.log('Achievement edited:', achievement);
              setCurrentScreen('yourAchievements');
            }}
          />
        );
      case 'evidenceDemo':
        return (
          <EvidenceSheetDemoScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'comparisonBreakdown':
      case 'comparison-breakdown':
        return (
          <ComparisonBreakdownScreen
            onBack={() => setCurrentScreen('home')}
            onGeneratePlan={() => {
              console.log('Generate plan from gaps');
              setCurrentScreen('plan');
            }}
            onAddAchievement={() => setCurrentScreen('addAchievement')}
          />
        );
      case 'statesLibrary':
        return (
          <StatesLibraryScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'profile':
        return (
          <ProfileScreen
            onBack={() => setCurrentScreen('home')}
            onEditProfile={() => setCurrentScreen('editProfile')}
            onNavigate={setCurrentScreen}
            onSwitchIdol={() => setCurrentScreen('idolSwitcherDemo')}
            onSettings={() => setCurrentScreen('settings')}
          />
        );
      case 'editProfile':
        return (
          <EditProfileScreen
            onBack={() => setCurrentScreen('profile')}
            onSave={(profile) => {
              console.log('Profile saved:', profile);
              setCurrentScreen('profile');
            }}
          />
        );
      case 'notifications':
        return (
          <NotificationsScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'idolSearch':
        return (
          <IdolSearchScreen
            onBack={() => setCurrentScreen('home')}
          />
        );
      default:
        return <SplashScreen onStart={() => setCurrentScreen('auth')} />;
    }
  };

  const showNavigation = ['home', 'timeline', 'comparison', 'plan', 'chat', 'notes'].includes(currentScreen);

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-4">
      {/* Screen selector for demo */}
      <div className="fixed top-4 left-4 z-50 bg-[#1C1C1E] rounded-[20px] p-4 border border-[#2A2A2E] max-w-xs">
        <h3 className="text-white text-sm mb-3">Screen Navigation</h3>
        <div className="space-y-2">
          {[
            { id: 'splash', label: '1. Splash' },
            { id: 'auth', label: '2. Auth Landing' },
            { id: 'profileSetup', label: '3. Profile Setup' },
            { id: 'onboarding', label: '4. Onboarding' },
            { id: 'ageInput', label: '5. Age Input' },
            { id: 'idols', label: '6. Idol Selection' },
            { id: 'discovery', label: '7. Discovery Results' },
            { id: 'confirm', label: '8. Confirm Idol' },
            { id: 'enrichment', label: '9. Timeline Enrichment' },
            { id: 'addAchievement', label: '10. Add Achievement' },
            { id: 'yourAchievements', label: '11. Your Achievements' },
            { id: 'achievementDetail', label: '12. Achievement Detail' },
            { id: 'editAchievement', label: '13. Edit Achievement' },
            { id: 'evidenceDemo', label: '14. Evidence Sheet Demo' },
            { id: 'comparisonBreakdown', label: '15. Comparison Breakdown' },
            { id: 'statesLibrary', label: '16. States Library' },
            { id: 'home', label: '17. Home Dashboard' },
            { id: 'timeline', label: '18. Idol Timeline' },
            { id: 'comparison', label: '19. Comparison' },
            { id: 'plan', label: '20. Plan Tracker' },
            { id: 'planItemDetail', label: '21. Plan Item Detail' },
            { id: 'chat', label: '22. Chat' },
            { id: 'notes', label: '23. Notes' },
            { id: 'newNote', label: '24. New Note' },
            { id: 'noteDetailDemo', label: '25. Note Detail Demo' },
            { id: 'idolSwitcherDemo', label: '26. Idol Switcher Demo' },
            { id: 'navigationMap', label: '27. Navigation Map' },
            { id: 'settings', label: '28. Settings' },
            { id: 'profile', label: '29. Profile' },
            { id: 'editProfile', label: '30. Edit Profile' },
            { id: 'notifications', label: '31. Notifications' },
            { id: 'idolSearch', label: '32. Idol Search' },
          ].map((screen) => (
            <button
              key={screen.id}
              onClick={() => setCurrentScreen(screen.id as Screen)}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all flex items-center justify-between group ${
                currentScreen === screen.id
                  ? 'bg-[#7B61FF] text-white'
                  : 'text-[#A1A1AA] hover:bg-[#2A2A2E]'
              }`}
            >
              {screen.label}
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>
      </div>

      {/* iPhone mockup */}
      <div className="relative">
        <div 
          className="bg-[#121212] rounded-[48px] overflow-hidden shadow-2xl border-8 border-[#1C1C1E]"
          style={{ width: '390px', height: '844px' }}
        >
          {/* Notch */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-7 bg-[#0A0A0A] rounded-b-3xl z-50" />
          
          {/* Screen content */}
          <div className="relative h-full overflow-hidden">
            {renderScreen()}
          </div>

          {/* Bottom Navigation (shown on main screens) */}
          {showNavigation && (
            <div className="absolute bottom-0 left-0 right-0 bg-[#1C1C1E]/95 backdrop-blur-lg border-t border-[#2A2A2E] px-4 py-3 pb-8">
              <div className="flex justify-around items-center">
                <button
                  onClick={() => setCurrentScreen('home')}
                  className={`flex flex-col items-center gap-1 ${
                    currentScreen === 'home' ? 'text-[#7B61FF]' : 'text-[#A1A1AA]'
                  }`}
                >
                  <Home className="w-5 h-5" />
                  <span className="text-[10px]">Home</span>
                </button>
                <button
                  onClick={() => setCurrentScreen('timeline')}
                  className={`flex flex-col items-center gap-1 ${
                    currentScreen === 'timeline' ? 'text-[#7B61FF]' : 'text-[#A1A1AA]'
                  }`}
                >
                  <Target className="w-5 h-5" />
                  <span className="text-[10px]">Timeline</span>
                </button>
                <button
                  onClick={() => setCurrentScreen('plan')}
                  className={`flex flex-col items-center gap-1 ${
                    currentScreen === 'plan' ? 'text-[#7B61FF]' : 'text-[#A1A1AA]'
                  }`}
                >
                  <BookOpen className="w-5 h-5" />
                  <span className="text-[10px]">Plan</span>
                </button>
                <button
                  onClick={() => setCurrentScreen('notes')}
                  className={`flex flex-col items-center gap-1 ${
                    currentScreen === 'notes' ? 'text-[#7B61FF]' : 'text-[#A1A1AA]'
                  }`}
                >
                  <FileText className="w-5 h-5" />
                  <span className="text-[10px]">Notes</span>
                </button>
                <button
                  onClick={() => setCurrentScreen('chat')}
                  className={`flex flex-col items-center gap-1 ${
                    currentScreen === 'chat' ? 'text-[#7B61FF]' : 'text-[#A1A1AA]'
                  }`}
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-[10px]">Chat</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}