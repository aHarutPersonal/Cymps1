# Video Background Instructions for Splash Screen

## How to Add Video Animation to Splash Screen

The splash screen (`/src/app/components/screens/SplashScreen.tsx`) has been prepared with a video background option that's currently commented out.

### Steps to Enable Video Background:

1. **Add your video file** to the `/public` directory of your project
   - Recommended format: MP4 (best browser compatibility)
   - Recommended resolution: 1080x1920 (portrait for mobile)
   - Keep file size under 5MB for optimal loading

2. **Uncomment the video element** in `SplashScreen.tsx`:
   ```tsx
   <video 
     className="absolute inset-0 w-full h-full object-cover opacity-20"
     autoPlay 
     loop 
     muted 
     playsInline
   >
     <source src="/your-video-name.mp4" type="video/mp4" />
   </video>
   ```

3. **Replace `/your-video-name.mp4`** with your actual video file path

### Video Recommendations:

- **Theme**: Abstract particles, gradient flows, or subtle geometric patterns
- **Style**: Match the purple (#7B61FF) color scheme
- **Duration**: 10-30 seconds (will loop)
- **Motion**: Slow, subtle movements for a premium feel
- **Opacity**: Currently set to 20% to ensure text readability

### Free Video Resources:

- **Pexels Videos**: https://www.pexels.com/videos/
- **Pixabay Videos**: https://pixabay.com/videos/
- **Coverr**: https://coverr.co/

### Search Terms for Finding Suitable Videos:
- "abstract purple background"
- "particle animation dark"
- "gradient flow animation"
- "minimalist motion background"
- "tech background animation"

### Performance Tip:
For better performance, consider using a shorter, optimized video or replacing it with CSS/SVG animations on lower-end devices.
