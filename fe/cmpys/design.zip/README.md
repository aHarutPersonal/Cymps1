
  # Premium Minimalist Dark UI

  This is a code bundle for Premium Minimalist Dark UI. The original project is available at https://www.figma.com/design/8a4F5QJOoZjlBpoMS0zl8h/Premium-Minimalist-Dark-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  